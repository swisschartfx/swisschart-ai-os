# AI START HERE

PROJECT:

Swisschart AI OS

DATE:

2026-08-09

---

# WHERE WE ARE

Telegram and Notion infrastructure is working.

Publishing Agent is working.

Risk Reminder is working.

Signal formatting and calculations are working.

Notion Journal Agent is working.

Latest successful Trade:

TSC-2646

Next Trade:

TSC-2647

---

# WHERE TO CONTINUE

DO NOT restart the project.

DO NOT rebuild Telegram.

DO NOT rebuild Notion.

DO NOT build the central Assistant yet.

Continue from:

REAL SIGNAL WORKFLOW

---

# NEXT SESSION

Start by checking:

05_CURRENT_STATUS.md

06_NEXT_ACTION.md

11_CHANGELOG.md

Then continue with:

REAL SIGNAL WORKFLOW

---

# SIGNAL BEHAVIOR

User says:

"سیگنال"

System:

1. Publish Risk Reminder
2. Ask Symbol
3. Ask Direction separately
4. Ask Entry
5. Ask Stop Loss
6. Ask TP1
7. Ask TP2
8. Ask Grade
9. Ask for Screenshot optionally
10. Ask for TradingView Link optionally

Never invent data.

Never assume Direction.

Never create a fake screenshot.

---

# AFTER SIGNAL

Calculate:

- Stop Size
- R:R TP1
- R:R TP2

Generate:

TSC-2647

Then:

Telegram → Signal

Notion → Journal Entry

---

# FUTURE

After Telegram/Signal is complete:

Scheduler

Then:

Calendar Agent + Forex Factory

Then:

Swisschart AI Assistant

---

# ASSISTANT ARCHITECTURE

Swisschart AI Assistant will become the central Orchestrator.

It will control:

- Journal Agent
- Publishing Agent
- Scheduler
- Calendar Agent
- Future Agents

User will communicate with the Assistant mainly in Persian.

The Assistant will translate the user's intent into the appropriate workflow and Agent actions.

---

# IMPORTANT

When modifying code:

Always provide the COMPLETE file.

User replaces the entire file.

Do not provide partial patches unless explicitly requested.

Do not use fake test data in the production Signal workflow.