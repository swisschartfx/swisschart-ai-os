﻿# SWISSCHART AI OS

## MASTER CONTEXT

Version: 3.0
Status: Active
Last Updated: 2026-08-11

---

# Purpose

This document is the single source of truth for the entire Swisschart AI OS project.

Every development session must begin by reading this document.

Its purpose is to restore the complete context of the project and ensure that all architectural and technical decisions follow the long-term vision of Swisschart.

Project documentation overrides chat history and AI memory when conflicts exist.

---

# Project Overview

Swisschart AI OS is the operating system of Swisschart.

It is not a standalone automation tool and it is not a collection of fixed Telegram scripts.

The system is intended to become an adaptive company intelligence and execution platform capable of coordinating specialized Agents, Services, Tasks, Events and Workflows.

Swisschart itself is not a signal-selling business and not an education business.

Swisschart is a long-term financial investment company.

Signals, content, memberships, automation and AI are business tools that support the company.

They are not the final product.

---

# Company Mission

Build long-term value for the company, its members and future investors through disciplined decision-making, technical analysis, professional risk management, operational excellence and artificial intelligence.

---

# Company Vision

Become one of the world's most trusted investment companies by combining financial expertise, operational excellence, proprietary market decision-making and artificial intelligence.

---

# Company Structure

Swisschart

↓

Swisschart DNA

↓

Swisschart Business System

↓

Swisschart AI Operating System

↓

Swisschart AI

↓

Specialized Agents

↓

Services

↓

External Systems

---

# AI Hierarchy

Mohammad AI

Personal Executive AI

↓

Swisschart AI

Company Operating AI

↓

AI Operating System

↓

Specialized Agents

↓

Services

↓

External Systems

---

# Swisschart AI Operating Model

Swisschart AI should act as the company's operating intelligence.

It coordinates the AI Operating System and delegates specialized work to Agents.

The system must support adaptive execution rather than require a separate hard-coded implementation for every new founder request.

---

# Core Intelligence Model

The long-term execution model is:

Natural Language Intent

↓

Assistant

↓

Task Definition / Event Detection

↓

Task Engine / Event Engine

↓

Scheduler / Workflow Engine

↓

Specialized Agents

↓

Services

↓

External Systems

↓

Execution Result

↓

Assistant / Memory / Knowledge

This model is the core architectural direction of Swisschart AI OS.

---

# Dynamic Task Philosophy

The founder should be able to describe a new requirement in natural language without requiring a developer to create a new permanent workflow file for every requirement.

Examples include:

- Create a recurring morning briefing
- Alert before an economic event
- Publish an event result
- Produce a market summary
- Generate a performance report
- Add or remove a recurring company operation

The system should create or configure the required Task / Event / Workflow using existing infrastructure whenever possible.

---

# Event-Driven Intelligence

Swisschart AI OS must support event-driven behavior.

Important event categories include:

- Economic events
- Market events
- News events
- Scheduled events
- Publication events
- External data changes

Example:

Forex Factory

↓

Economic Event

↓

Event Engine

↓

Pre-event alert

↓

Event release

↓

Result retrieval

↓

Analysis

↓

Content generation

↓

Telegram publication

This must be implemented as a reusable capability rather than a separate hard-coded system for every event.

---

# Agent Philosophy

Every Agent has one primary responsibility.

Agents contain domain or business logic.

Agents do not directly communicate with external APIs.

They communicate through Services.

Current and planned Agents include:

- Journal Agent
- Content Agent
- Publishing Agent
- Calendar Agent
- Forex Factory Agent
- Market Research Agent
- Performance Agent
- CEO Agent
- Marketing Agent
- Assistant Agent
- Future Specialized Agents

---

# Service Philosophy

Services are responsible for external-system communication.

Examples:

- Notion Service
- Telegram Service
- TradingView Service
- Instagram Service
- OpenAI Service
- Database Service
- Website Service

Agents should not contain raw external API calls.

---

# Scheduler Philosophy

Scheduler is infrastructure.

It is responsible for time.

It must remain independent of business logic.

Scheduler responsibilities include:

- One-time tasks
- Recurring tasks
- Daily execution
- Timezone handling
- DST support
- Event timing

Scheduler does not decide what a task means or what content should be produced.

---

# Content System Position

Content is a capability of the AI Operating System.

Content Agent remains responsible for content formatting and content-related business logic.

Publishing Agent and Telegram Service remain responsible for publication infrastructure.

Fixed Content workflow files must not become the long-term architecture for every new content requirement.

Reusable workflow execution should eventually be handled through the Workflow Engine and Task / Event system.

---

# Current Development Philosophy

Swisschart AI OS follows Spiral Development.

Foundation

↓

Useful Agent

↓

Save Time

↓

Reinvest Saved Time

↓

Build Better System

↓

Repeat

Architecture is more important than speed.

Documentation is part of the product.

Every component should remain useful and understandable over the long term.

Business requirements drive technology.

Technology does not drive the business.

---

# Source of Truth

The source of truth is NOT:

❌ Chat history

❌ AI memory

The source of truth IS:

✅ Project Brain

When conversation and Project Brain conflict, Project Brain wins.

---

# Session Workflow

Every development session follows this order:

1. Read MASTER_CONTEXT.md
2. Read CURRENT_STATUS.md
3. Read NEXT_ACTION.md
4. Review relevant architecture documents
5. Verify the intended architecture before creating new files
6. Continue implementation
7. Update Project Brain when architecture or project state changes

Development is not complete until relevant documentation reflects the implemented state.

---

# Current Strategic Objective

Build the foundation of an adaptive AI Operating System that allows Swisschart AI Assistant to:

- Understand natural-language requests
- Create and manage dynamic tasks
- React to events
- Coordinate specialized Agents
- Use verified internal knowledge
- Schedule execution
- Publish results
- Adapt to new founder requirements without major redesign

---

# Long-Term Objective

The final objective is not to build software.

The final objective is not to sell signals.

The final objective is to build a world-class investment company capable of operating independently while preserving the founder's philosophy, competitive advantage, standards and Swisschart DNA for decades.
