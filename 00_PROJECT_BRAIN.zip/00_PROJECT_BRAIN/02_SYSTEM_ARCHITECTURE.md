﻿# SWISSCHART AI OS

# SYSTEM ARCHITECTURE

Version: 2.0
Status: Active
Last Updated: 2026-08-11

---

# System Hierarchy

Mohammad AI

↓

Swisschart AI

↓

AI Operating System

↓

Intelligence & Coordination Layer

↓

Task Engine / Event Engine / Workflow Engine / Scheduler

↓

Specialized Agents

↓

Services

↓

External Systems

---

# Mohammad AI

## Role

Personal Executive AI

## Responsibilities

- Personal Planning
- Personal Knowledge
- Decision Support
- Company Supervision
- Long-term Strategy

Mohammad AI manages and supervises multiple company AI systems.

---

# Swisschart AI

## Role

Company Operating AI

## Responsibilities

- Manage Agents
- Protect Swisschart DNA
- Coordinate company operations
- Coordinate AI Operating System
- Delegate business tasks
- Supervise intelligent workflows

Swisschart AI does NOT directly perform specialized business tasks.

It delegates work to specialized agents and system components.

---

# AI Operating System

The AI Operating System is the execution and coordination infrastructure of Swisschart AI.

## Responsibilities

- Workflow Management
- Task Management
- Event Management
- Scheduling
- Automation
- Decision Flow
- Agent Coordination
- Memory / Knowledge Connection
- Service Coordination
- Execution Tracking

The AI Operating System must remain independent from specific business tasks.

---

# Intelligence & Coordination Layer

The Intelligence & Coordination Layer connects natural-language intent with system execution.

Core components:

- Task Engine
- Event Engine
- Workflow Engine
- Scheduler
- Agent Registry
- Memory / Knowledge Layer
- Execution State

The layer must support adaptive behavior.

The system must NOT require a new hard-coded workflow file for every new business requirement.

---

# Task Engine

The Task Engine manages dynamic tasks created by the Assistant or internal system logic.

Responsibilities:

- Create tasks
- Validate tasks
- Update tasks
- Enable / disable tasks
- Store task definitions
- Trigger task execution
- Track task state

Tasks should describe WHAT needs to happen, not contain external API logic.

---

# Event Engine

The Event Engine manages events that can trigger system actions.

Examples:

- Economic events
- Market events
- News events
- Scheduled events
- Publication events
- External data changes

The Event Engine should support:

- Event detection
- Event matching
- Event scheduling
- Pre-event actions
- Event-time actions
- Post-event actions

Example:

Forex Factory Event

↓

5-minute pre-alert

↓

Event release

↓

Result retrieval

↓

Analysis

↓

Telegram publication

This must be implemented as a reusable event pattern, not as a separate hard-coded system for every economic event.

---

# Workflow Engine

The Workflow Engine converts a Task or Event into an executable sequence.

Responsibilities:

- Resolve workflow
- Select required agents
- Pass data between agents
- Execute steps
- Handle failures
- Return execution result
- Record execution state

Workflows should be reusable and composable.

Avoid creating permanent standalone workflows for temporary content requests.

---

# Scheduler

The Scheduler is a generic time execution engine.

Responsibilities:

- One-time execution
- Recurring execution
- Daily tasks
- Timezone handling
- DST support
- Task timing
- Event timing

Scheduler MUST NOT contain business logic.

Scheduler does NOT decide:

- What Morning Message means
- What a news event means
- What content should be produced
- What information should be researched

It only determines WHEN an approved task or event should execute.

---

# Agent Layer

Every Agent has ONE primary responsibility.

Examples:

- Journal Agent
- Content Agent
- Publishing Agent
- Calendar Agent
- Forex Factory Agent
- Market Research Agent
- Performance Agent
- CEO Agent
- Marketing Agent
- Assistant Agent
- Future Agents

Agents perform business or domain logic.

Agents do not directly communicate with external APIs.

They use Services.

---

# Assistant Agent

The Swisschart AI Assistant is the primary natural-language interface to the AI Operating System.

Responsibilities:

- Understand natural-language requests
- Interpret user intent
- Create tasks
- Create schedules
- Modify tasks
- Remove tasks
- Coordinate Agents
- Query verified internal knowledge
- Request market intelligence
- Trigger workflows
- Report execution status

The Assistant should be capable of adapting to new tasks without requiring a new hard-coded command for every use case.

---

# Calendar / Forex Factory Intelligence

Market-calendar intelligence should be handled by specialized Agents.

Example architecture:

Calendar Agent

↓

Forex Factory Agent

↓

Economic Event Data

↓

Event Engine

↓

Task / Workflow Execution

The system should be able to retrieve weekly and daily event information and use that information to drive intelligent content and alerts.

---

# Service Layer

Services communicate with external systems.

Examples:

- Notion Service
- Telegram Service
- TradingView Service
- Instagram Service
- OpenAI Service
- Database Service
- Website Service

Agents never communicate directly with APIs.

Agents communicate only with Services.

---

# External Systems

Examples:

- Notion
- Telegram
- TradingView
- Instagram
- X (Twitter)
- Website
- Database
- Cloud Storage
- External Market Data Sources
- Forex Factory

---

# Core Rules

## Rule 1

One Agent = One Primary Responsibility

---

## Rule 2

One Service = One External System

---

## Rule 3

Business Logic belongs inside Agents

---

## Rule 4

External API calls belong inside Services

---

## Rule 5

Scheduler contains timing logic only

---

## Rule 6

Task Engine owns dynamic task definitions

---

## Rule 7

Event Engine owns event-driven triggers

---

## Rule 8

Workflow Engine owns execution sequences

---

## Rule 9

Assistant controls the AI OS through natural language

---

## Rule 10

Project Brain is the source of truth

---

## Rule 11

Avoid hard-coded solutions for temporary business requirements

---

## Rule 12

New capabilities must fit the architecture without requiring major redesign

---

# Adaptive Architecture Principle

Swisschart AI OS must remain adaptive.

The system should allow the founder to introduce a new requirement without automatically requiring:

- A new Scheduler implementation
- A new Telegram implementation
- A new Agent architecture
- A new hard-coded command
- A new permanent workflow file

The preferred pattern is:

Assistant

↓

Task Definition

↓

Event / Workflow Engine

↓

Specialized Agent

↓

Service

↓

External System

---

# Example

Founder request:

"Every weekday at 7:00 AM New York time, send a morning market briefing."

System:

Assistant

↓

Task Engine

↓

Scheduler

↓

Workflow Engine

↓

Calendar / Market Agents

↓

Content Agent

↓

Publishing Agent

↓

Telegram Service

↓

Telegram

The same infrastructure should support future requests such as:

- Five-minute event alerts
- Post-event result publication
- Market summaries
- News analysis
- Scheduled reports
- New custom recurring tasks

without redesigning the core system.

---

# Long-Term Goal

The architecture should allow hundreds of Agents and thousands of tasks and events to work together while remaining understandable, maintainable and extensible.

Every new component should fit naturally into this architecture.

The architecture must support the long-term goal:

Build a world-class investment company capable of operating for decades while preserving Swisschart DNA, competitive advantage and standards.
