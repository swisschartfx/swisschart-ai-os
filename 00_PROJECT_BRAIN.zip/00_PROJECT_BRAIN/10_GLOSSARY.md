# SWISSCHART AI OS
# GLOSSARY

Version: 1.0
Status: Active
Last Updated: 2026-08-07

---

# Purpose

This document defines the official terminology used throughout the Swisschart AI OS project.

Every document, agent and developer should use these definitions consistently.

---

## Project Brain

The permanent knowledge base of the project.

---

## DNA

The company's identity, philosophy and core beliefs.

---

## Constitution

The non-negotiable rules that govern the company and its AI systems.

---

## Agent

A software component responsible for one business task.

Example:

Journal Agent

Content Agent

Research Agent

---

## Service

A component responsible for communicating with one external system.

Example:

Notion Service

Telegram Service

Instagram Service

---

## Workflow

A sequence of actions performed automatically.

---

## Sprint

A focused development phase with defined goals.

---

## ADR

Architecture Decision Record.

A permanent record explaining why an architectural decision was made.

---

## Source of Truth

The official location where information is considered correct.

For this project:

Project Brain.

---

## Spiral Development

A development method where useful software is built early and continuously improves itself by saving time.

---

## Trade Secret

Confidential knowledge that creates Swisschart's competitive advantage.

---

## AI OS

The operating system responsible for running the company's AI infrastructure.

---

## Mohammad AI

Personal Executive AI.

The highest AI layer.

---

## Swisschart AI

Company Executive AI.

Responsible for coordinating all business agents.