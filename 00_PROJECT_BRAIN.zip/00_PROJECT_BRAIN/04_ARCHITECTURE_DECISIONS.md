# SWISSCHART AI OS
# ARCHITECTURE DECISIONS

Version: 1.0
Status: Active
Last Updated: 2026-08-07

---

# Purpose

This document records all major architectural decisions.

Every important decision must include:

• The decision

• The reason

• The expected long-term benefit

This prevents repeating discussions and protects the project's direction.

---

# ADR-001

Title

Swisschart AI OS is the Operating System of the company.

Decision

Swisschart AI OS exists to execute the Swisschart Business System.

Reason

The company is bigger than the software.

Software may evolve.

The company philosophy must remain.

---

# ADR-002

Title

Project Brain becomes the Source of Truth.

Decision

Project documentation replaces chat history as the project's memory.

Reason

AI memory is limited.

Chat history cannot become the company's knowledge base.

Project Brain provides permanent documentation.

---

# ADR-003

Title

Spiral Development

Decision

The project follows Spiral Development instead of Waterfall.

Reason

Useful agents should start saving time early.

Saved time is reinvested into building better systems.

---

# ADR-004

Title

Architecture before Speed

Decision

Long-term architecture always has higher priority than short-term development speed.

Reason

Technical debt becomes expensive over time.

A clean architecture reduces future costs.

---

# ADR-005

Title

Single Responsibility Principle

Decision

Every Agent has one responsibility.

Every Service has one responsibility.

Reason

Smaller components are easier to maintain, replace and test.

---

# ADR-006

Title

Service Layer

Decision

Agents never communicate directly with external APIs.

All communication happens through Services.

Reason

External providers can change.

Only the Service Layer should be affected.

---

# ADR-007

Title

Project Documentation

Decision

Documentation is considered part of the product.

Reason

The company must survive beyond conversations and individual developers.

---

# ADR-008

Title

Website before Mobile App

Decision

Website has higher priority than native mobile applications.

Reason

The business model should be validated before maintaining mobile applications.

---

# ADR-009

Title

Business before Technology

Decision

Technology exists to support the business.

Reason

No feature should be developed without clear business value.

---

# ADR-010

Title

Long-term Thinking

Decision

Every major architectural decision should still make sense five years from now.

Reason

Swisschart is being built as a decades-long company, not a short-term software project.

---

# Future Decisions

Every future architectural decision should be added to this document with a new ADR number.


---

# ADR-011

Title

Swisschart AI is the Central Company Orchestrator.

Decision

Swisschart AI will coordinate specialized Agents and workflows instead of directly performing every business task.

Mohammad AI remains the Personal Executive AI.

Swisschart AI remains the Company Operating AI.

Reason

Clear separation between personal executive intelligence, company orchestration and specialized business responsibilities is required for long-term scalability.

Expected Long-term Benefit

The architecture can expand to many specialized Agents without turning the central AI into an oversized component.

---

# ADR-012

Title

Assistant Before Direct Agent Expansion

Decision

The central Swisschart AI Assistant will be built only after Telegram Content, Scheduler and Calendar foundations are stable.

Reason

The Assistant depends on reliable internal workflows and verified external data.

Expected Long-term Benefit

The Assistant becomes an orchestrator of proven capabilities rather than a layer built on unstable infrastructure.
---

# ADR — Content Workflow Prototype Archive

Date: 2026-08-11

## Decision

Content-specific workflow files created during early development are treated as prototypes and are not part of the permanent AI OS architecture.

Archived prototypes:

- Morning Message Workflow
- Market Update Workflow
- London Open Workflow
- New York Open Workflow

## Reason

The long-term architecture must not create a permanent workflow file for every business request.

Content execution should eventually be handled through:

Assistant

↓

Task Engine / Event Engine

↓

Workflow Engine

↓

Content Agent

↓

Publishing Service

↓

External System

## Impact

Existing prototype files are preserved for reference.

Future content automation should be implemented through reusable AI OS infrastructure.

